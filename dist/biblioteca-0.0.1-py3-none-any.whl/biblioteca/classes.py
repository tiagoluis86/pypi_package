class Livro:
    def __init__(self, titulo, autor, ano, genero, sinopse):
        self.titulo = titulo
        self.autor = autor
        self.ano = ano
        self.genero = genero
        self.sinopse = sinopse