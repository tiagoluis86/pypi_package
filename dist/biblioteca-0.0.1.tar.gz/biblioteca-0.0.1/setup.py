
from setuptools import setup, find_packages


setup(
    name="biblioteca",
    version="0.0.1",
    author="tiagoluis86",
    author_email="tiagoluis86",
    description="Pacote de app de biblioteca para treinamento no uso de pacotes",
   
    long_description_content_type="text/markdown",
    url="github/tiagoluis86",
    packages=find_packages(),
   
    python_requires='>=3.8',
)
    
